"""Exact money, bounded ingestion and device isolation. No access to the ERP database."""
import hashlib
import hmac
import json
import secrets
import sqlite3
import time
import threading
from functools import wraps
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from zoneinfo import ZoneInfo

CONNECTION_TIMEOUT_MS = 45 * 60 * 1000
ANALYTICS=threading.BoundedSemaphore(2)

def bounded(function):
    @wraps(function)
    def wrapped(*args,**kwargs):
        if not ANALYTICS.acquire(timeout=1):
            raise TimeoutError("El panel está procesando otra consulta. Vuelve a intentar.")
        try:return function(*args,**kwargs)
        finally:ANALYTICS.release()
    return wrapped


ZONE = ZoneInfo("America/El_Salvador")
KINDS = {"sale", "cash", "return"}
METHODS = {"EFECTIVO", "TARJETA", "TRANSFERENCIA"}


def cents(value):
    if not isinstance(value, str) or len(value) > 20:
        raise ValueError("Monto inválido")
    try:
        n = Decimal(value)
        if not n.is_finite() or n < 0 or n > Decimal("999999999.99") or n * 100 != (n * 100).to_integral_value():
            raise ValueError("Monto inválido")
        return int(n * 100)
    except InvalidOperation as error:
        raise ValueError("Monto inválido") from error


def integer(value, minimum=0, maximum=2**53 - 1):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError("Número inválido")
    return value


def text(value, limit=160):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 for c in value):
        raise ValueError("Texto inválido")
    return value


def validate(kind, entity, data):
    if data is None:
        return None
    if not isinstance(data, dict) or str(integer(data.get("id"), 1)) != entity:
        raise ValueError("Registro inválido")
    business = text(data.get("business"), 100)
    if not business:
        raise ValueError("Negocio requerido")
    base = dict(id=data["id"], business=business, created=integer(data.get("created"), 1), cashier=text(data.get("cashier", ""), 100))
    if kind == "sale":
        total, discount = cents(data.get("total")), cents(data.get("discount", "0.00"))
        items = data.get("items")
        if not isinstance(items, list) or not 1 <= len(items) <= 500:
            raise ValueError("Detalle de venta inválido")
        clean, gross = [], 0
        for item in items:
            qty, price = integer(item.get("qty"), 1, 1000000), cents(item.get("price"))
            cost = None if item.get("cost") is None else cents(item["cost"])
            clean.append(dict(id=integer(item.get("id"), 1), name=text(item.get("name"), 500), qty=qty, price=price, cost=cost))
            gross += qty * price
        if gross != total + discount:
            raise ValueError("La venta no coincide con su detalle")
        payments = data.get("payments")
        if not isinstance(payments, list) or not 1 <= len(payments) <= 100:
            raise ValueError("Pagos inválidos")
        amounts = {}
        for payment in payments:
            method = payment.get("method")
            if method not in METHODS:
                raise ValueError("Método inválido")
            amounts[method] = amounts.get(method, 0) + cents(payment.get("amount"))
        if sum(amounts.values()) != total:
            raise ValueError("Los pagos no coinciden con la venta")
        base.update(total=total, discount=discount, items=clean, payments=amounts)
    elif kind == "cash":
        base.update(closed=integer(data.get("closed", 0)), opening=cents(data.get("opening", "0.00")))
        for field in ("expected", "counted"):
            base[field] = None if data.get(field) is None else cents(data[field])
    else:
        base.update(total=cents(data.get("total")), sale=integer(data.get("sale"), 1))
        if base["id"] != base["sale"]:
            raise ValueError("Devolución inválida")
    return base


class Store:
    def __init__(self, path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY,label TEXT NOT NULL,token_hash TEXT NOT NULL,epoch INTEGER NOT NULL DEFAULT 0,last_seen INTEGER NOT NULL DEFAULT 0,complete INTEGER NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS records(device TEXT NOT NULL,epoch INTEGER NOT NULL,kind TEXT NOT NULL,entity TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT,created INTEGER NOT NULL,business TEXT NOT NULL,PRIMARY KEY(device,epoch,kind,entity));
            CREATE INDEX IF NOT EXISTS records_date ON records(kind,created,business);
            CREATE TABLE IF NOT EXISTS business_names(device TEXT NOT NULL,epoch INTEGER NOT NULL,business TEXT NOT NULL,label TEXT NOT NULL,PRIMARY KEY(device,epoch,business));
            CREATE TABLE IF NOT EXISTS geo_points(pos_device TEXT NOT NULL,mdm_device TEXT NOT NULL,located_at INTEGER NOT NULL CHECK(located_at>0),latitude REAL NOT NULL CHECK(latitude BETWEEN -90 AND 90),longitude REAL NOT NULL CHECK(longitude BETWEEN -180 AND 180),accuracy_m REAL,received_at INTEGER NOT NULL,PRIMARY KEY(pos_device,mdm_device,located_at,latitude,longitude));
            CREATE INDEX IF NOT EXISTS geo_day ON geo_points(pos_device,mdm_device,located_at DESC);
            CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,csrf TEXT NOT NULL,expires INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS login_limits(key TEXT PRIMARY KEY,attempts INTEGER NOT NULL,expires INTEGER NOT NULL);
            """)
            # Existing last_seen values cannot reveal whether a packet held movements.
            columns = {row["name"] for row in db.execute("PRAGMA table_info(devices)")}
            if "last_data_received" not in columns:
                db.execute("ALTER TABLE devices ADD COLUMN last_data_received INTEGER NOT NULL DEFAULT 0")

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=5)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def geo_row(row):
        from urllib.parse import quote
        item=dict(row)
        item["map_url"]="https://www.google.com/maps/search/?api=1&query="+quote(str(item["latitude"])+","+str(item["longitude"]))
        if item["accuracy_m"] is None:item.pop("accuracy_m")
        return item

    def save_geo_points(self,config,points,received_at):
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            device=db.execute("SELECT enabled FROM devices WHERE id=?",(config["pos_device"],)).fetchone()
            if device is None or not device["enabled"]:raise PermissionError("Dispositivo desactivado")
            db.executemany("INSERT INTO geo_points VALUES(?,?,?,?,?,?,?) ON CONFLICT DO NOTHING",((config["pos_device"],config["mdm_device"],p["located_at"],p["latitude"],p["longitude"],p.get("accuracy_m"),received_at) for p in points))

    def last_geo_point(self,config):
        with self.connect() as db:
            row=db.execute("SELECT located_at,latitude,longitude,accuracy_m,received_at FROM geo_points WHERE pos_device=? AND mdm_device=? ORDER BY located_at DESC,latitude,longitude LIMIT 1",(config["pos_device"],config["mdm_device"])).fetchone()
            return None if row is None else self.geo_row(row)

    def geo_history(self,config,day,page=0,for_map=False):
        lower,upper=self.range(day,day)
        if type(page) is not int or not 0<=page<=2000:raise ValueError("Página inválida")
        args=(config["pos_device"],config["mdm_device"],lower,upper)
        with self.connect() as db:
            db.execute("BEGIN")
            device=db.execute("SELECT label FROM devices WHERE id=? AND enabled=1",(config["pos_device"],)).fetchone()
            if device is None:raise PermissionError("Dispositivo desactivado")
            totals=db.execute("SELECT count(*),min(located_at),max(located_at) FROM geo_points WHERE pos_device=? AND mdm_device=? AND located_at>=? AND located_at<?",args).fetchone()
            if for_map:
                rows=db.execute("SELECT located_at,latitude,longitude,accuracy_m,received_at FROM geo_points WHERE pos_device=? AND mdm_device=? AND located_at>=? AND located_at<? ORDER BY located_at,latitude,longitude LIMIT 20001",args).fetchall()
                return dict(configured=True,status="ok",device_label=device["label"],day=day,total=totals[0],truncated=len(rows)>20000,rows=[self.geo_row(row) for row in rows[:20000]])
            rows=db.execute("SELECT located_at,latitude,longitude,accuracy_m,received_at FROM geo_points WHERE pos_device=? AND mdm_device=? AND located_at>=? AND located_at<? ORDER BY located_at DESC,latitude,longitude LIMIT 101 OFFSET ?",(*args,page*100)).fetchall()
        return dict(configured=True,status="ok",device_label=device["label"],day=day,page=page,total=totals[0],first_at=totals[1],last_at=totals[2],has_more=len(rows)>100,rows=[self.geo_row(row) for row in rows[:100]])

    def add_device(self, label):
        device, token = secrets.token_hex(16), secrets.token_urlsafe(40)
        with self.connect() as db:
            db.execute("INSERT INTO devices(id,label,token_hash) VALUES(?,?,?)", (device, text(label, 100), hashlib.sha256(token.encode()).hexdigest()))
        return device, token

    def put_business_names(self, device, token, body):
        if not isinstance(body, dict) or set(body) != {"protocol", "epoch", "businesses"} or type(body["protocol"]) is not int or body["protocol"] != 1:
            raise ValueError("Catálogo inválido")
        epoch=integer(body["epoch"],1)
        if not isinstance(body["businesses"],list) or len(body["businesses"])>500:
            raise ValueError("Catálogo demasiado grande")
        names={}
        for item in body["businesses"]:
            if not isinstance(item,dict) or set(item)!={"id","name"}:
                raise ValueError("Nombre inválido")
            identity,label=text(item["id"],100),text(item["name"],100).strip()
            if not identity or not label or identity in names:
                raise ValueError("Negocio inválido o repetido")
            names[identity]=label
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row=db.execute("SELECT epoch,token_hash,enabled FROM devices WHERE id=?",(device,)).fetchone()
            if row is None or not row["enabled"] or not hmac.compare_digest(row["token_hash"],hashlib.sha256(token.encode()).hexdigest()):
                raise PermissionError("Dispositivo no autorizado")
            if epoch<row["epoch"]:
                raise LookupError("Generación anterior")
            db.execute("DELETE FROM business_names WHERE device=? AND epoch=?",(device,epoch))
            db.executemany("INSERT INTO business_names VALUES(?,?,?,?)",((device,epoch,key,value) for key,value in names.items()))
        return dict(protocol=1,epoch=epoch,accepted=len(names))

    def business_labels(self, db):
        labels={}
        for row in db.execute("SELECT n.business,n.label FROM business_names n JOIN devices d ON d.id=n.device AND d.epoch=n.epoch WHERE d.enabled=1 ORDER BY n.business,n.label"):
            labels.setdefault(row["business"],set()).add(row["label"])
        # A shared legacy ID can have different labels on different terminals.
        return {key:" / ".join(sorted(values)) for key,values in labels.items()}

    def ingest(self, device, token, body):
        if not isinstance(body, dict) or set(body) != {"protocol", "epoch", "complete", "events"} or body["protocol"] != 1:
            raise ValueError("Protocolo inválido")
        epoch = integer(body["epoch"], 1)
        if type(body["complete"]) is not bool or not isinstance(body["events"], list) or len(body["events"]) > 25:
            raise ValueError("Lote inválido")
        events, identities = [], set()
        for event in body["events"]:
            if not isinstance(event, dict) or set(event) != {"kind", "entity", "revision", "data"}:
                raise ValueError("Evento inválido")
            kind, entity = event["kind"], event["entity"]
            if kind not in KINDS or not isinstance(entity, str) or not entity.isascii() or not entity.isdigit() or not 1 <= len(entity) <= 16:
                raise ValueError("Identidad inválida")
            if (kind, entity) in identities:
                raise ValueError("Registro repetido en lote")
            identities.add((kind, entity))
            events.append((kind, entity, integer(event["revision"], 1), validate(kind, entity, event["data"])))
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM devices WHERE id=?", (device,)).fetchone()
            if row is None or not row["enabled"] or not hmac.compare_digest(row["token_hash"], hashlib.sha256(token.encode()).hexdigest()):
                raise PermissionError("Dispositivo no autorizado")
            if epoch < row["epoch"]:
                raise LookupError("Generación anterior")
            for kind, entity, revision, data in events:
                # A tombstone retains its revision so an old retry cannot resurrect it.
                db.execute("""INSERT INTO records VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(device,epoch,kind,entity) DO UPDATE SET revision=excluded.revision,payload=excluded.payload,created=excluded.created,business=excluded.business WHERE excluded.revision>records.revision""", (device, epoch, kind, entity, revision, None if data is None else json.dumps(data, ensure_ascii=False, separators=(",", ":")), 0 if data is None else data["created"], "" if data is None else data["business"]))
            received_at = int(time.time() * 1000)
            db.execute("UPDATE devices SET epoch=?,last_seen=?,last_data_received=CASE WHEN ? THEN ? ELSE last_data_received END,complete=? WHERE id=?", (epoch, received_at, bool(events), received_at, int(body["complete"]), device))
        return dict(protocol=1, device=device, epoch=epoch, accepted=[dict(kind=k, entity=e, revision=r) for k, e, r, _ in events])

    def range(self, start, end):
        first, last = date.fromisoformat(start), date.fromisoformat(end)
        if last < first or (last - first).days > 365:
            raise ValueError("Selecciona hasta 366 días")
        return int(datetime.combine(first, datetime.min.time(), ZONE).timestamp()*1000), int(datetime.combine(last+timedelta(days=1), datetime.min.time(), ZONE).timestamp()*1000)

    def read_records(self, db, kind, start, end, business=""):
        # Filter cash by closure before loading JSON; old shifts must not exhaust
        # the report budget, and a shift can close after its opening day.
        clock = "CAST(json_extract(r.payload, '$.closed') AS INTEGER)" if kind == "cash" else "r.created"
        cursor = db.execute(f"""SELECT r.device,r.payload FROM records r JOIN devices d ON d.id=r.device AND d.epoch=r.epoch WHERE d.enabled=1 AND r.kind=? AND {clock}>=? AND {clock}<? AND (?='' OR r.business=?) AND r.payload IS NOT NULL ORDER BY {clock} DESC LIMIT 50001""", (kind, start, end, business, business))
        result=[];size=0
        for row in cursor:
            size+=len(row["payload"].encode("utf-8"))
            if len(result)>=50000 or size>8*1024*1024:
                raise ValueError("Reduce el intervalo para consultar este volumen de ventas")
            result.append((row["device"],json.loads(row["payload"])))
        return result

    @staticmethod
    def allocations(sale):
        gross = sum(i["qty"]*i["price"] for i in sale["items"])
        if not gross:
            return [0] * len(sale["items"])
        values = [i["qty"]*i["price"]*sale["total"]//gross for i in sale["items"]]
        remainders = sorted(range(len(values)), key=lambda n: (-((sale["items"][n]["qty"]*sale["items"][n]["price"]*sale["total"]) % gross), n))
        for n in remainders[:sale["total"]-sum(values)]:
            values[n] += 1
        return values

    @bounded
    def summary(self, start, end, business=""):
        lower, upper = self.range(start, end)
        with self.connect() as db:
            db.execute("BEGIN")
            sales = self.read_records(db, "sale", lower, upper, business)
            refunds = self.read_records(db, "return", lower, upper, business)
            cash = self.read_records(db, "cash", lower, upper, business)
            now = int(time.time() * 1000)
            devices = [dict(r) for r in db.execute("SELECT id,label,last_seen,last_data_received,complete FROM devices WHERE enabled=1")]
            for device in devices:
                device["connection_active"] = bool(device["last_seen"] and now - device["last_seen"] <= CONNECTION_TIMEOUT_MS)
                device["connection_timeout_minutes"] = CONNECTION_TIMEOUT_MS // 60000
            business_labels = self.business_labels(db)
            businesses = [r[0] for r in db.execute("SELECT DISTINCT r.business FROM records r JOIN devices d ON d.id=r.device AND d.epoch=r.epoch WHERE d.enabled=1 AND r.business<>'' ORDER BY r.business")]
            previous_sales = self.read_records(db, "sale", lower-(upper-lower), lower, business)
            previous_returns = self.read_records(db, "return", lower-(upper-lower), lower, business)
            entries = [(device, sale, 1, sale["created"]) for device, sale in sales]
            for device, refund in refunds:
                row = db.execute("SELECT r.payload FROM records r JOIN devices d ON d.id=r.device AND d.epoch=r.epoch WHERE r.device=? AND r.kind='sale' AND r.entity=? AND r.payload IS NOT NULL", (device, str(refund["sale"]))).fetchone()
                if row is None:
                    raise LookupError("Sincronización en curso: falta el detalle de una devolución")
                original = json.loads(row[0])
                if original["total"] != refund["total"]:
                    raise ValueError("Devolución inconsistente")
                entries.append((device, original, -1, refund["created"]))
        revenue = sum(s["total"] for _, s in sales)
        refunded = sum(r["total"] for _, r in refunds)
        net = revenue-refunded
        previous = sum(s["total"] for _, s in previous_sales)-sum(r["total"] for _, r in previous_returns)
        payments, products, hours, days = {}, {}, [0]*24, {}
        cost, cost_known, units = 0, True, 0
        for device, sale, sign, created in entries:
            local = datetime.fromtimestamp(created/1000, ZONE)
            day = local.date().isoformat()
            days[day] = days.get(day, 0)+sign*sale["total"]
            hours[local.hour] += sign*sale["total"]
            for method, amount in sale["payments"].items():
                payments[method] = payments.get(method, 0)+sign*amount
            for item, amount in zip(sale["items"], self.allocations(sale)):
                key = (sale["business"], device, item["id"])
                p = products.setdefault(key, dict(name=item["name"], business=sale["business"], qty=0, total=0))
                p["qty"] += sign*item["qty"]
                p["total"] += sign*amount
                units += sign*item["qty"]
                if item["cost"] is None:
                    cost_known = False
                else:
                    cost += sign*item["cost"]*item["qty"]
        calendar_days=[]
        cursor=date.fromisoformat(start)
        while cursor<=date.fromisoformat(end):
            calendar_days.append(dict(day=cursor.isoformat(),total=days.get(cursor.isoformat(),0)))
            cursor+=timedelta(days=1)
        closed=[]
        for device, shift in cash:
            if lower <= shift["closed"] < upper:
                closed.append(dict(device=device, **shift, difference=None if shift["expected"] is None or shift["counted"] is None else shift["counted"]-shift["expected"]))
        daily={}
        for shift in closed:
            key=(shift["business"],datetime.fromtimestamp(shift["closed"]/1000,ZONE).date().isoformat())
            item=daily.setdefault(key,dict(business=key[0],day=key[1],sessions=0,expected=0,counted=0,difference=0))
            item["sessions"]+=1
            for field in ("expected","counted","difference"):
                item[field]+=shift[field] or 0
        return dict(daily_cash=list(daily.values()),currency="USD", timezone="America/El_Salvador", from_date=start, to_date=end, businesses=businesses, business_labels=business_labels, devices=devices, net=net, gross=revenue, refunds=refunded, returns=len(refunds), transactions=len(sales), units=units, discounts=sum(s["discount"] for _, s in sales), minimum=min((s["total"] for _, s in sales), default=None), maximum=max((s["total"] for _, s in sales), default=None), average=None if not sales else int((Decimal(revenue)/Decimal(len(sales))).quantize(Decimal("1"),rounding="ROUND_HALF_UP")), profit=net-cost if cost_known else None, margin=None if not cost_known or net<=0 else round((net-cost)*100/net,2), previous=previous, change=None if previous<=0 else round((net-previous)*100/previous,2), payments=[dict(method=k,total=v,percent=round(v*100/net,2) if net>0 else None) for k,v in sorted(payments.items(),key=lambda x:-x[1])], products=sorted(products.values(),key=lambda p:-p["total"])[:10], hours=hours, days=calendar_days, cash=sorted(closed,key=lambda s:-s["closed"])[:100])

    @bounded
    def transactions(self, start, end, business="", page=0, query=""):
        lower, upper = self.range(start, end)
        with self.connect() as db:
            db.execute("BEGIN")
            rows=self.read_records(db,"sale",lower,upper,business)
            query=query.casefold().strip()[:100]
            rows=[(d,s) for d,s in rows if not query or query in str(s["id"]) or query in s["cashier"].casefold() or any(query in i["name"].casefold() for i in s["items"])]
            selected=rows[page*30:page*30+30]
            result=[]
            for device,sale in selected:
                returned=db.execute("SELECT 1 FROM records r JOIN devices d ON d.id=r.device AND d.epoch=r.epoch WHERE r.device=? AND r.kind='return' AND r.entity=? AND r.payload IS NOT NULL",(device,str(sale["id"]))).fetchone() is not None
                result.append(dict(device=device,returned=returned,**sale))
            return dict(rows=result,total=len(rows),page=page,has_more=(page+1)*30<len(rows))
