"""Isaval Pos Dashboard — independent, read-only reporting service."""
