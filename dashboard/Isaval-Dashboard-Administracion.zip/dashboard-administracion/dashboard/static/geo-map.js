"use strict";
let geoMap=null,geoLayers=null,geoLineLayer=null,geoMapPoints=[],geoMarkers=[],geoMapDay=null,geoMapSerial=0;
let geoMapSignature='',geoMapCaption='',geoMapDevice=null;
const GEO_GAP_MS=30*60*1000;
function geoSegments(points){
 const segments=[];let segment=[];
 for(const point of points){
  if(segment.length&&point.located_at-segment[segment.length-1].located_at>GEO_GAP_MS){if(segment.length>1)segments.push(segment);segment=[];}
  segment.push(point);
 }
 if(segment.length>1)segments.push(segment);
 return segments;
}
function geoGroups(points){
 const groups=new Map();
 points.forEach((point,index)=>{const key=point.latitude+','+point.longitude;if(!groups.has(key))groups.set(key,[]);groups.get(key).push({point,index});});
 return [...groups.values()];
}
function clearGeoMap(){
 if(geoMap){geoMap.remove();geoMap=null;}
 geoLayers=null;geoLineLayer=null;geoMarkers=[];geoMapPoints=[];geoMapDay=null;
 geoMapSignature='';geoMapCaption='';geoMapDevice=null;
 $("geoMap").hidden=true;$("geoMapTools").hidden=true;
 $("geoPoint").replaceChildren();
}
function fitGeoMap(){
 if(!geoMap||!geoMapPoints.length)return;
 geoMap.invalidateSize();geoMap.fitBounds(L.latLngBounds(geoMapPoints.map(p=>[p.latitude,p.longitude])),{padding:[30,30],maxZoom:17});
}
function drawGeoLines(){
 if(!geoLineLayer)return;geoLineLayer.clearLayers();
 if(!$("geoConnect").checked)return;
 for(const segment of geoSegments(geoMapPoints))L.polyline(segment.map(p=>[p.latitude,p.longitude]),{color:'#426b83',weight:3,opacity:.65,dashArray:'6 8',interactive:false}).addTo(geoLineLayer);
}
function renderGeoMap(data){
 const points=(data.rows||[]).slice().sort((a,b)=>a.located_at-b.located_at||a.latitude-b.latitude||a.longitude-b.longitude);
 if(!points.length){clearGeoMap();$("geoMapStatus").textContent=!data.configured?'Vincula ManageEngine para ver el mapa.':data.status!=='ok'?'Revisa la vinculación de ManageEngine en la HP.':'No hay puntos guardados para este día.';return;}
 const signature=JSON.stringify([data.day,$('geoDevice').value,data.total,data.truncated,points]);
 if(geoMap&&signature===geoMapSignature){$("geoMapStatus").textContent=geoMapCaption;return;}
 if(typeof L==='undefined'){clearGeoMap();$("geoMapStatus").textContent='No se pudo cargar el mapa. El listado sigue disponible.';return;}
 const changedDay=geoMapDay!==data.day,first=!geoMap;
 $("geoMap").hidden=false;$("geoMapTools").hidden=false;
 if(!geoMap){
  geoMap=L.map('geoMap',{preferCanvas:true,scrollWheelZoom:false});
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,referrerPolicy:'origin',attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors'}).on('tileerror',()=>{$("geoMapStatus").textContent='El fondo del mapa no está disponible. Los puntos y el listado siguen disponibles; prueba actualizar.';}).addTo(geoMap);
  geoLineLayer=L.layerGroup().addTo(geoMap);geoLayers=L.layerGroup().addTo(geoMap);
  $("geoFit").onclick=fitGeoMap;$("geoConnect").onchange=drawGeoLines;
  $("geoPoint").onchange=()=>{const index=Number($("geoPoint").value),point=geoMapPoints[index];if(point){geoMap.setView([point.latitude,point.longitude],Math.max(geoMap.getZoom(),16));geoMarkers[index].openPopup();}};
 }
 geoMapDay=data.day;geoMapDevice=$('geoDevice').value;geoMapPoints=points;geoLayers.clearLayers();geoMarkers=[];
 $("geoPoint").replaceChildren();
 points.forEach((point,index)=>{const option=document.createElement('option');option.value=String(index);option.textContent=`${index+1} · ${fmtDate(point.located_at,{timeStyle:'medium'})}`;$("geoPoint").append(option);});
 for(const group of geoGroups(points)){
  const firstIndex=group[0].index,lastIndex=group[group.length-1].index,isStart=firstIndex===0,isEnd=lastIndex===points.length-1;
  const title=(isStart&&isEnd?'Inicio y fin':isStart?'Inicio':isEnd?'Último punto':'Punto '+(firstIndex+1))+(group.length>1?' · '+group.length+' lecturas':'');
  const marker=L.circleMarker([group[0].point.latitude,group[0].point.longitude],{radius:isStart||isEnd?9:6,color:'#fff',weight:2,fillColor:isEnd?'#bb9759':isStart?'#33725d':'#294b65',fillOpacity:.95}).addTo(geoLayers);
  const popup=document.createElement('div');popup.className='geo-popup';
  const heading=document.createElement('strong');heading.textContent=title;popup.append(heading);
  const list=document.createElement('ol');
  for(const {point,index} of group){const item=document.createElement('li');item.textContent=`#${index+1} · ${fmtDate(point.located_at,{timeStyle:'medium'})}${point.accuracy_m===undefined?'':' · Precisión '+number(point.accuracy_m)+' m'}`;list.append(item);geoMarkers[index]=marker;}
  popup.append(list);marker.bindPopup(popup).bindTooltip(title+' · '+fmtDate(group[0].point.located_at,{timeStyle:'medium'}));
 }
 drawGeoLines();geoMap.invalidateSize();if(first||changedDay)fitGeoMap();
 $("geoMapStatus").textContent=`${number(points.length)} de ${number(data.total)} puntos del día · Verde: inicio · Dorado: último punto.${data.truncated?' Hay más de 20,000 lecturas: el mapa muestra las primeras 20,000; el listado conserva todas.':''}`;
 geoMapSignature=signature;geoMapCaption=$("geoMapStatus").textContent;
}
async function loadGeoMap(){
 const serial=++geoMapSerial,day=$("geoDay").value;
 if(demo){clearGeoMap();$("geoMapStatus").textContent='El mapa estará disponible al vincular tu SUNMI.';return;}
 // Clear immediately when changing day, so previous-day points cannot be mistaken for the selection.
 if(geoMapDay!==day||geoMapDevice!==$('geoDevice').value)clearGeoMap();
 $("geoMapStatus").textContent='Cargando los puntos del día…';
 try{const data=await api('/api/geolocation?'+new URLSearchParams({day,view:'map',device:$("geoDevice").value}));if(serial!==geoMapSerial)return;renderGeoMap(data);}
 catch(error){if(serial!==geoMapSerial)return;clearGeoMap();$("geoMapStatus").textContent=error.message;}
}
