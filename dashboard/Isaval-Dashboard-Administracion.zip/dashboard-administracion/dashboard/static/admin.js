"use strict";
let adminDevices=[],adminRows=[],adminEpoch=0,adminPage=0,adminBusinessRevision=0,adminBusinesses=[],adminSerial=0,adminCommandPage=0;
const adminKinds={product:'Productos',customer:'Clientes',user:'Usuarios',business:'Negocios',stock:'Movimientos de inventario'};
function adminDevice(){return $('adminDevice').value;}
function adminRequest(path,values){return api(path,{method:'POST',headers:{'X-CSRF-Token':csrf},body:JSON.stringify(values)});}
async function loadAdministration(){
 if(demo){$('adminNotice').textContent='La administración está disponible con tu sesión y equipos reales.';return;}
 try{
  const d=await api('/api/admin/devices');adminDevices=d.devices;const current=adminDevice(),geo=$('geoDevice').value;
  $('adminDevice').innerHTML=d.devices.map(v=>`<option value="${escape(v.id)}">${escape(v.label)}${v.enabled?'':' · Desactivado'}</option>`).join('');
  if(d.devices.some(v=>v.id===current))$('adminDevice').value=current;
  $('geoDevice').innerHTML='<option value="">Equipo principal</option>'+d.devices.filter(v=>v.enabled).map(v=>`<option value="${escape(v.id)}">${escape(v.label)}</option>`).join('');$('geoDevice').value=geo;
  await loadAdminCatalog();loadAdminCommands();
 }catch(e){$('adminNotice').textContent=e.message;}
}
async function loadAdminCatalog(){
 const serial=++adminSerial,device=adminDevice();adminRows=[];$('adminRows').replaceChildren();$('adminNext').disabled=true;$('adminPrevious').disabled=true;
 if(!device||demo)return;
 $('adminNotice').textContent='Consultando catálogo confirmado por la SUNMI…';
 try{
  const [catalog,businesses]=await Promise.all([api('/api/admin/catalog?'+new URLSearchParams({device,kind:$('adminKind').value,q:$('adminSearch').value,page:adminPage,business:$('adminKind').value==='user'||$('adminKind').value==='business'?'':$('adminBusiness').value})),api('/api/admin/catalog?'+new URLSearchParams({device,kind:'business'}))]);
  if(serial!==adminSerial)return;
  adminEpoch=catalog.epoch;adminBusinessRevision=businesses.rows[0]?.revision||0;adminBusinesses=businesses.rows[0]?.data.items||[];
  const chosen=$('adminBusiness').value;$('adminBusiness').innerHTML='<option value="">Todos los negocios</option>'+adminBusinesses.map(b=>`<option value="${escape(b.id)}">${escape(b.name)}</option>`).join('');$('adminBusiness').value=chosen;
  $('adminNotice').textContent=catalog.ready?'Último catálogo confirmado: '+fmtDate(catalog.seen)+'. Las existencias pertenecen a este equipo; pueden cambiar mientras vende.':'Pendiente de catálogo: instala la nueva APK y sincroniza este equipo.';
  adminRows=catalog.rows;const kind=$('adminKind').value;
  if(kind==='business')adminRows=adminBusinesses.map(b=>({entity:'catalog',revision:adminBusinessRevision,data:b}));
  const label=id=>adminBusinesses.find(b=>b.id===id)?.name||id||'Equipo';
  $('adminRows').innerHTML=adminRows.length?adminRows.map((r,i)=>{const p=r.data;return `<tr><td><strong>${escape(kind==='stock'?(p.product_name||'Producto #'+p.product_id):p.name)}</strong><small>${escape(kind==='stock'?'Movimiento #'+p.id+' · '+p.reason:kind==='user'?p.role:label(p.business||p.id))}</small></td><td>${kind==='product'?`${number(p.stock)} unidades<small>${escape(money(Math.round(Number(p.price)*100)))}</small>`:kind==='stock'?`${p.delta>0?'+':''}${number(p.delta)}<small>${escape(fmtDate(p.created))}</small>`:p.active===0?'Inactivo':'Activo'}</td><td>${kind!=='stock'?`<button class="ticket-link" data-admin-edit="${i}">Editar</button>`:escape(p.cashier)}</td><td>${kind==='product'?`<button class="ticket-link" data-admin-stock="${i}">Inventario</button> <button class="ticket-link" data-admin-copy="${i}">Copiar a equipo</button>`:kind==='stock'?`${number(p.before_stock)} → ${number(p.after_stock)}`:''}</td></tr>`;}).join(''):'<tr><td colspan="4" class="empty">No hay fichas para estos filtros.</td></tr>';
  $('adminCount').textContent=number(catalog.total)+' registros · Página '+(adminPage+1);$('adminPrevious').disabled=adminPage===0;$('adminNext').disabled=!catalog.has_more;
  document.querySelectorAll('[data-admin-edit]').forEach(b=>b.onclick=()=>adminEditor(adminRows[+b.dataset.adminEdit]));
  document.querySelectorAll('[data-admin-stock]').forEach(b=>b.onclick=()=>adminStock(adminRows[+b.dataset.adminStock]));
  document.querySelectorAll('[data-admin-copy]').forEach(b=>b.onclick=()=>adminCopy(adminRows[+b.dataset.adminCopy]));
 }catch(e){if(serial===adminSerial)$('adminNotice').textContent=e.message;}
}
async function loadAdminCommands(){
 const device=adminDevice();if(!device||demo)return;
 try{const d=await api('/api/admin/commands?'+new URLSearchParams({device,page:adminCommandPage}));if(device!==adminDevice())return;
  const statuses={pending:'Pendiente',applied:'Aplicado',review:'Requiere revisión',cancelled:'Cancelado'};
  $('adminCommands').innerHTML=d.rows.length?d.rows.map(r=>`<article class="admin-command"><div><strong>${escape(r.title||adminKinds[r.kind]||r.kind)} · ${escape(statuses[r.status])}</strong><small>${escape(fmtDate(r.created))} · ${escape(r.actor)}${r.delivered&&r.status==='pending'?' · Entregado; esperando confirmación':''}</small><p>${escape(r.detail||'')}</p><p>${escape(r.result?.message||'Se aplicará cuando el equipo sincronice. No vuelvas a enviarlo.')}</p></div>${r.status==='pending'&&!r.delivered?`<button class="secondary" data-admin-cancel="${escape(r.id)}">Cancelar</button>`:''}</article>`).join(''):'<p class="empty">Aún no hay cambios enviados desde la web.</p>';
  $('adminCommandPrevious').disabled=adminCommandPage===0;$('adminCommandNext').disabled=!d.has_more;
  document.querySelectorAll('[data-admin-cancel]').forEach(b=>b.onclick=async()=>{try{await adminRequest('/api/admin/cancel',{id:b.dataset.adminCancel});loadAdminCommands();}catch(e){$('adminNotice').textContent=e.message;}});
 }catch(e){$('adminNotice').textContent=e.message;}
}
function adminDialog(title,html,submit){
 $('adminDialogTitle').textContent=title;$('adminFormBody').innerHTML=html;$('adminFormError').textContent='';$('adminSave').disabled=false;
 $('adminForm').onsubmit=async e=>{e.preventDefault();$('adminSave').disabled=true;$('adminFormError').textContent='';try{await submit(new FormData($('adminForm')));$('adminDialog').close();await loadAdministration();}catch(err){$('adminFormError').textContent=err.message;}finally{$('adminSave').disabled=false;}};
 $('adminDialog').showModal();
}
const af=(name,label,value='',type='text',extra='')=>`<label>${escape(label)}<input name="${name}" type="${type}" value="${escape(value)}" ${extra}></label>`;
function abusiness(chosen){return `<label>Negocio<select name="business" required>${adminBusinesses.map(b=>`<option value="${escape(b.id)}"${chosen===b.id?' selected':''}>${escape(b.name)}</option>`).join('')}</select></label>`;}
function activeField(value){return `<label>Estado<select name="active"><option value="1"${value!==0?' selected':''}>Activo</option><option value="0"${value===0?' selected':''}>Inactivo</option></select></label>`;}
async function queueAdmin(kind,entity,expected,action,payload,device=adminDevice(),epoch=adminEpoch,requestId=crypto.randomUUID()){
 await adminRequest('/api/admin/commands',{request_id:requestId,device,epoch,kind,entity,expected,action,payload});
}
async function adminImage(file){
 if(!file||!file.size)return '';if(file.size>8*1024*1024)throw Error('La imagen original debe ser menor a 8 MB.');
 const url=URL.createObjectURL(file);try{const img=new Image();await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(Error('No se pudo abrir la imagen.'));img.src=url;});const canvas=document.createElement('canvas'),scale=Math.min(1,640/Math.max(img.width,img.height));canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);let quality=.8,encoded;do{encoded=canvas.toDataURL('image/jpeg',quality).split(',')[1];quality-=.15;}while(encoded.length>105000&&quality>.15);if(encoded.length>105000)throw Error('La imagen es demasiado compleja; usa una más pequeña.');return encoded;}finally{URL.revokeObjectURL(url);}
}
function adminEditor(row=null){
 const kind=$('adminKind').value;if(kind==='stock')return;const p=row?.data||{},device=adminDevice(),epoch=adminEpoch;if(!epoch){$('adminNotice').textContent='Espera a que este equipo envíe su catálogo.';return;}
 const requestId=crypto.randomUUID();let html=af('name','Nombre',p.name||'','text','required maxlength="100"');
 if(kind==='product')html+=abusiness(p.business)+af('ticket_name','Nombre para ticket · máximo 28 caracteres',p.ticket_name||'','text','maxlength="28"')+af('code','Código de barras · vacío para generar uno',p.code||'','text','maxlength="100"')+af('category','Categoría',p.category||'General','text','required maxlength="100"')+af('price','Precio de venta',p.price||'0.00','number','required min="0" step="0.01"')+af('cost','Costo',p.cost||'0.00','number','required min="0" step="0.01"')+(!row?af('stock','Existencias iniciales',0,'number','required min="0" max="1000000" step="1"'):'')+af('minimum','Existencias mínimas',p.minimum??5,'number','required min="0" max="1000000" step="1"')+`<label>Preparación<select name="preparation"><option value="1"${p.preparation!==0?' selected':''}>Incluir en comanda</option><option value="0"${p.preparation===0?' selected':''}>No requiere preparación</option></select></label><label>Fotografía ${p.has_image?'· ya tiene imagen en la SUNMI':''}<input name="photo" type="file" accept="image/*"></label><p class="footnote">Deja la fotografía vacía para conservar la actual. Cambia existencias desde Inventario.</p>`;
 if(kind==='customer'){html+=abusiness(p.business);for(const [key,label] of Object.entries({phone:'Teléfono',email:'Correo',legal_name:'Razón social',nit:'NIT',nrc:'NRC',address:'Dirección',activity:'Actividad económica'}))html+=af(key,label,p[key]||'',key==='email'?'email':'text');}
 if(kind==='user')html+=`<label>Rol<select name="role">${['Administrador','Supervisor','Cajero'].map(v=>`<option${(p.role||'Cajero')===v?' selected':''}>${v}</option>`).join('')}</select></label>`+af('pin',row?'Nuevo PIN · vacío para conservarlo':'PIN de 4 dígitos','','password',`inputmode="numeric" pattern="[0-9]{4}" maxlength="4" autocomplete="new-password"${row?'':' required'}`)+`<label>Negocios permitidos<select name="businesses" multiple>${adminBusinesses.map(b=>`<option value="${escape(b.id)}"${p.businesses?.includes(b.id)?' selected':''}>${escape(b.name)}</option>`).join('')}</select></label><p class="footnote">Sin selección: todos los negocios. Los administradores conservan acceso completo. Estos usuarios acceden a la SUNMI; no crean nuevas cuentas web.</p>`;
 if(kind==='business')html+=af('description','Descripción',p.description||'','text','maxlength="200"');
 html+=activeField(p.active)+`<p class="footnote">El cambio quedará pendiente hasta la confirmación del equipo. Una ficha con historial se conserva inactiva.</p>`;
 adminDialog((row?'Editar ':'Crear ')+({product:'producto',customer:'cliente',user:'usuario',business:'negocio'}[kind]),html,async form=>{
  const payload=Object.fromEntries([...form.entries()].filter(([k,v])=>typeof v==='string'));payload.active=+payload.active;
  if(kind==='product'){for(const k of ['minimum','preparation','stock'])if(k in payload)payload[k]=Number(payload[k]);const image=await adminImage(form.get('photo'));if(image)payload.image_data=image;}
  if(kind==='user')payload.businesses=form.getAll('businesses');
  if(kind==='business')payload.business=p.id||'';
  await queueAdmin(kind,row?.entity||'0',kind==='business'?adminBusinessRevision:row?.revision||0,'save',payload,device,epoch,requestId);
 });
}
function adminStock(row){
 const device=adminDevice(),epoch=adminEpoch,p=row.data,requestId=crypto.randomUUID();
 adminDialog('Inventario · '+p.name,`<p>Últimas existencias reportadas: <strong>${number(p.stock)}</strong>. Las entradas y salidas se calculan sobre el stock que tenga la SUNMI al recibirlas.</p><label>Operación<select name="action"><option value="stock_delta">Entrada o salida de unidades</option><option value="stock_count">Ajustar a conteo físico</option></select></label>`+af('quantity','Unidades · negativo para salida',0,'number','required step="1" min="-1000000" max="1000000"')+af('reason','Motivo','','text','required maxlength="200"')+'<p class="footnote">El conteo físico requiere que la ficha no haya cambiado desde la última consulta. Si hubo una venta, quedará para revisión.</p>',async form=>queueAdmin('product',row.entity,row.revision,form.get('action'),{quantity:Number(form.get('quantity')),reason:form.get('reason'),business:p.business},device,epoch,requestId));
}
function adminDeviceEditor(fresh=false){
 const device=fresh?null:adminDevices.find(v=>v.id===adminDevice());const p=device||{};
 adminDialog(fresh?'Agregar equipo':'Administrar equipo',af('label','Nombre del equipo',p.label||'','text','required maxlength="100"')+af('mdm_device','ID de dispositivo ManageEngine · opcional',p.mdm_device||'','text','pattern="[0-9]{1,24}"')+(fresh?'':`<label>Estado<select name="enabled"><option value="1"${p.enabled?' selected':''}>Habilitado</option><option value="0"${p.enabled?'':' selected'}>Desactivado</option></select></label>`)+`<label><input name="rotate" type="checkbox">Generar una nueva vinculación (invalida la anterior)</label><p class="footnote">Cada equipo necesita su propio archivo de vinculación. Instala la APK, importa el archivo y sincroniza. Desactivar bloquea la comunicación con el servidor; no apaga ni borra la SUNMI.</p>`,async form=>{
  const values=Object.fromEntries(form);if(device)values.id=device.id;values.enabled=Number(values.enabled??1);values.rotate=form.get('rotate')==='on';const d=await adminRequest('/api/admin/devices',values);
  if(d.pairing){const blob=new Blob([JSON.stringify(d.pairing,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='isaval-vinculacion-'+d.id.slice(0,8)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);$('adminNotice').textContent='Archivo privado descargado. Impórtalo solo en la nueva SUNMI y retíralo de Descargas después.';}
 });
}
function adminCopy(row){
 const requestId=crypto.randomUUID();adminDialog('Copiar producto a otro equipo',`<p>Se creará una ficha independiente con stock inicial en cero.</p><label>Equipo destino<select name="device" id="adminCopyDevice">${adminDevices.filter(v=>v.enabled&&v.id!==adminDevice()).map(v=>`<option value="${escape(v.id)}">${escape(v.label)}</option>`).join('')}</select></label><label>Negocio destino<select name="business" id="adminCopyBusiness" required></select></label>`,async form=>{const device=form.get('device'),d=await api('/api/admin/catalog?'+new URLSearchParams({device,kind:'business'}));if(!d.ready)throw Error('El equipo destino debe sincronizar primero.');const p={...row.data,business:form.get('business'),stock:0};delete p.id;delete p.last_move;delete p.has_image;await queueAdmin('product','0',0,'save',p,device,d.epoch,requestId);});
 const fill=async()=>{try{const d=await api('/api/admin/catalog?'+new URLSearchParams({device:$('adminCopyDevice').value,kind:'business'}));$('adminCopyBusiness').innerHTML=(d.rows[0]?.data.items||[]).map(b=>`<option value="${escape(b.id)}">${escape(b.name)}</option>`).join('');}catch(e){$('adminFormError').textContent=e.message;}};$('adminCopyDevice').onchange=fill;fill();
}
$('adminClose').onclick=()=>{if(!$('adminSave').disabled)$('adminDialog').close();};
$('adminDevice').onchange=()=>{adminPage=0;adminCommandPage=0;$('adminBusiness').value='';loadAdminCatalog();loadAdminCommands();};
$('adminKind').onchange=()=>{adminPage=0;loadAdminCatalog();};$('adminBusiness').onchange=()=>{adminPage=0;loadAdminCatalog();};
$('adminSearchButton').onclick=()=>{adminPage=0;loadAdminCatalog();};$('adminRefresh').onclick=loadAdministration;
$('adminCreate').onclick=()=>adminEditor();$('adminAddDevice').onclick=()=>adminDeviceEditor(true);$('adminEditDevice').onclick=()=>adminDeviceEditor(false);
$('adminPrevious').onclick=()=>{if(adminPage){adminPage--;loadAdminCatalog();}};$('adminNext').onclick=()=>{adminPage++;loadAdminCatalog();};
$('adminCommandPrevious').onclick=()=>{if(adminCommandPage){adminCommandPage--;loadAdminCommands();}};$('adminCommandNext').onclick=()=>{adminCommandPage++;loadAdminCommands();};
$('geoDevice').onchange=()=>{geoPage=0;loadLocation();loadGeoHistory();loadGeoMap();};
setInterval(()=>{if(!demo&&!document.hidden&&!$('dashboard').hidden&&!$('adminDialog').open)loadAdminCommands();},60000);

if(!$('dashboard').hidden)loadAdministration();
