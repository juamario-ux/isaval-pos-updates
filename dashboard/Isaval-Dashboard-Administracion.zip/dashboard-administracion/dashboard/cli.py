"""Administrative commands run on the HP. Pairing secrets never enter source control."""
import argparse
import getpass
import json
import os
import secrets
from pathlib import Path
from urllib.parse import urlsplit
from .store import Store
from .server import password_hash


def write_private(path, data):
    descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(descriptor,"w") as stream:
        json.dump(data,stream,ensure_ascii=False,indent=2)
        stream.write("\n")


def main():
    parser=argparse.ArgumentParser(description="Isaval Pos Dashboard")
    parser.add_argument("--data",default=os.environ.get("DASHBOARD_DATA","/data"))
    sub=parser.add_subparsers(dest="command",required=True)
    init=sub.add_parser("init");init.add_argument("--username",default="mario");init.add_argument("--origin",required=True)
    pair=sub.add_parser("add-device");pair.add_argument("--label",required=True);pair.add_argument("--url",required=True);pair.add_argument("--output",required=True)
    mdm=sub.add_parser("mdm-setup");mdm.add_argument("--device",required=True);mdm.add_argument("--mdm-device",required=True)
    sub.add_parser("devices")
    disable=sub.add_parser("disable-device");disable.add_argument("id")
    backup=sub.add_parser("backup");backup.add_argument("--output",required=True)
    args=parser.parse_args();root=Path(args.data);root.mkdir(parents=True,exist_ok=True)
    if args.command=="init":
        u=urlsplit(args.origin)
        if u.scheme!="https" or not u.netloc or u.username or u.query or u.fragment or u.path not in ("","/"):
            parser.error("Usa el origen HTTPS definitivo, sin rutas")
        password=getpass.getpass("Contraseña de administrador (12 caracteres mínimo): ")
        if not 12<=len(password)<=256 or password!=getpass.getpass("Repite la contraseña: "):
            parser.error("Contraseñas inválidas")
        salt=secrets.token_hex(16)
        write_private(root/"config.json",dict(username=args.username,salt=salt,password_hash=password_hash(password,salt),origin=args.origin.rstrip("/"),secure_cookie=True))
        print("Administrador configurado. Reinicia el servicio para cargarlo.")
        return
    store=Store(root/"dashboard.sqlite3")
    if args.command=="mdm-setup":
        from .mdm import MDM,request_json,validate_config,TOKEN,API
        with store.connect() as db:
            device=db.execute("SELECT label FROM devices WHERE id=? AND enabled=1",(args.device,)).fetchone()
        if device is None:parser.error("El equipo debe estar vinculado y habilitado en el Dashboard")
        if not args.mdm_device.isdigit() or len(args.mdm_device)>24:parser.error("Identificador MDM inválido")
        client_id=getpass.getpass("Client ID de Zoho (oculto): ").strip()
        client_secret=getpass.getpass("Client Secret (oculto): ").strip()
        code=getpass.getpass("Código temporal Self Client (oculto): ").strip()
        try:
            reply=request_json(TOKEN,dict(grant_type="authorization_code",client_id=client_id,client_secret=client_secret,code=code))
            config=validate_config(dict(region="US",pos_device=args.device,mdm_device=args.mdm_device,client_id=client_id,client_secret=client_secret,refresh_token=reply.get("refresh_token")))
            adapter=MDM(root);status=adapter.get(config)
            if status["status"] not in ("ok","empty"):raise ValueError()
        except Exception:parser.error("No se pudo validar la autorización. Revisa código vigente, región .com y permiso MDMOnDemand.MDMInventory.READ. No se guardaron las claves.")
        temporary=root/(".mdm-"+secrets.token_hex(8)+".json")
        write_private(temporary,config);os.replace(temporary,root/"mdm.json")
        print("ManageEngine vinculado. Solo lectura; credenciales privadas guardadas en el servidor. Recarga el Dashboard.")
        return
    if args.command=="add-device":
        u=urlsplit(args.url)
        if u.scheme!="https" or not u.netloc or u.username or u.query or u.fragment or u.path not in ("","/"):
            parser.error("Usa la dirección HTTPS del Dashboard, sin rutas")
        if Path(args.output).exists():
            parser.error("El archivo de destino ya existe")
        device,token=store.add_device(args.label)
        write_private(args.output,dict(protocol=1,url=args.url.rstrip("/"),device=device,token=token))
        print("Archivo de vinculación creado. Transfiérelo solo a la SUNMI y retíralo de Descargas tras importarlo.")
    elif args.command=="devices":
        with store.connect() as db:
            for row in db.execute("SELECT id,label,enabled,last_seen FROM devices"):
                print(dict(row))
    elif args.command=="disable-device":
        with store.connect() as db:
            db.execute("UPDATE devices SET enabled=0 WHERE id=?",(args.id,))
        print("Dispositivo desactivado.")
    else:
        import sqlite3
        if Path(args.output).exists():
            parser.error("El respaldo ya existe")
        descriptor=os.open(args.output,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.close(descriptor)
        with store.connect() as db,sqlite3.connect(args.output) as destination:
            db.backup(destination)
        print("Copia consistente del Dashboard creada; conserva también config.json de forma privada.")


if __name__=="__main__":
    main()
