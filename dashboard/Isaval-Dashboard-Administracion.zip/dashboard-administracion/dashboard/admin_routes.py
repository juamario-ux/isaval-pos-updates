import hmac,json,secrets,re,hashlib
from fastapi import HTTPException,Request
from fastapi.responses import FileResponse
from . import admin
from .store import text,integer

def install(app,store,config,session,same_origin,body,device_auth,static):
    admin.init(store)
    with store.connect() as db:db.execute('CREATE TABLE IF NOT EXISTS mdm_links(device TEXT PRIMARY KEY,mdm_device TEXT NOT NULL)')
    def authorize(request):
        same_origin(request);row=session(request)
        if not hmac.compare_digest(request.headers.get('x-csrf-token',''),row['csrf']):raise HTTPException(403,'Solicitud no autorizada')
    def error(exc):
        if isinstance(exc,PermissionError):return HTTPException(403,str(exc))
        if isinstance(exc,LookupError):return HTTPException(409,str(exc))
        return HTTPException(400,str(exc) if isinstance(exc,(ValueError,TypeError)) else 'Revisa los datos')
    @app.get('/admin.js')
    def javascript():return FileResponse(static/'admin.js',media_type='text/javascript')
    @app.get('/api/admin/devices')
    def devices(request:Request):
        session(request)
        with store.connect() as db:
            rows=db.execute('SELECT d.id,d.label,d.enabled,d.last_seen,a.epoch,a.seen,l.mdm_device FROM devices d LEFT JOIN admin_devices a ON a.device=d.id LEFT JOIN mdm_links l ON l.device=d.id ORDER BY d.label,d.id').fetchall()
            return dict(devices=[dict(r) for r in rows])
    @app.post('/api/admin/devices')
    async def save_device(request:Request):
        authorize(request);values=await body(request,4096)
        try:
            label=text(values.get('label',''),100).strip()
            if not label:raise ValueError('Ingresa el nombre del equipo')
            mdm_id=text(values.get('mdm_device',''),24)
            if mdm_id and not mdm_id.isdigit():raise ValueError('ID ManageEngine inválido')
            device=values.get('id');created=not device;pair=None
            if device and (not isinstance(device,str) or not re.fullmatch('[a-f0-9]{32}',device)):raise ValueError('Equipo inválido')
            if created:
                device,token=store.add_device(label)
                pair=dict(protocol=1,url=config['origin'],device=device,token=token)
            else:
                active=integer(values.get('enabled',1),0,1)
                with store.connect() as db:
                    db.execute('BEGIN IMMEDIATE')
                    if db.execute('UPDATE devices SET label=?,enabled=? WHERE id=?',(label,active,device)).rowcount!=1:raise ValueError('Equipo no encontrado')
            if not created and values.get('rotate') is True:
                token=secrets.token_urlsafe(40)
                with store.connect() as db:db.execute('UPDATE devices SET token_hash=? WHERE id=?',(hashlib.sha256(token.encode()).hexdigest(),device))
                pair=dict(protocol=1,url=config['origin'],device=device,token=token)
            with store.connect() as db:
                if mdm_id:db.execute('INSERT OR REPLACE INTO mdm_links VALUES(?,?)',(device,mdm_id))
            return dict(id=device,pairing=pair)
        except (ValueError,TypeError,KeyError,AttributeError) as e:raise error(e)
    @app.get('/api/admin/catalog')
    def catalog(request:Request):
        session(request)
        try:return admin.state(store,request.query_params.get('device',''),request.query_params.get('kind','product'),int(request.query_params.get('page','0')),request.query_params.get('q',''),request.query_params.get('business',''))
        except (ValueError,TypeError,PermissionError) as e:raise error(e)
    @app.get('/api/admin/commands')
    def commands(request:Request):
        session(request)
        try:return admin.commands(store,request.query_params.get('device',''),int(request.query_params.get('page','0')))
        except (ValueError,TypeError) as e:raise error(e)
    @app.post('/api/admin/commands')
    async def queue(request:Request):
        authorize(request);values=await body(request)
        try:return admin.queue(store,values,config.get('username','Administrador'))
        except (ValueError,TypeError,KeyError,AttributeError,PermissionError,LookupError) as e:raise error(e)
    @app.post('/api/admin/cancel')
    async def cancel(request:Request):
        authorize(request);values=await body(request,2048)
        try:return admin.cancel(store,str(values.get('id','')))
        except (ValueError,LookupError) as e:raise error(e)
    @app.post('/api/v1/admin-sync')
    async def exchange(request:Request):
        device,token=device_auth(request);values=await body(request)
        try:return admin.exchange(store,device,token,values)
        except PermissionError:raise HTTPException(401,'Equipo no autorizado')
        except LookupError:raise HTTPException(409,'Generación anterior')
        except (ValueError,TypeError,KeyError,AttributeError):raise HTTPException(400,'Lote de mantenimiento inválido')
