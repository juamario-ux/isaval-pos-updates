"""Read-only ManageEngine Cloud adapter. Secrets remain in /data, never in responses."""
import json
import math
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

API='https://mdm.manageengine.com'
TOKEN='https://accounts.zoho.com/oauth/v2/token'

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        raise ValueError('Redirect rejected')

def request_json(url,form=None,token=None):
    data=None if form is None else urllib.parse.urlencode(form).encode()
    request=urllib.request.Request(url,data=data,headers={'Accept':'application/json'})
    if form is not None:request.add_header('Content-Type','application/x-www-form-urlencoded')
    if token:request.add_header('Authorization','Zoho-oauthtoken '+token)
    with urllib.request.build_opener(NoRedirect).open(request,timeout=6) as response:
        data=response.read(1024*1024+1)
    if len(data)>1024*1024:raise ValueError('Response limit')
    result=json.loads(data)
    if not isinstance(result,dict):raise ValueError('Invalid response')
    return result

def validate_config(config):
    if config.get('region')!='US' or not re.fullmatch(r'[0-9]{1,24}',config.get('mdm_device','')) or not re.fullmatch(r'[a-f0-9]{32}',config.get('pos_device','')):
        raise ValueError('Configuración MDM inválida')
    for key in ('client_id','client_secret','refresh_token'):
        value=config.get(key)
        if not isinstance(value,str) or not 1<=len(value)<=512 or any(ord(c)<33 or ord(c)>126 for c in value):raise ValueError('Credencial MDM inválida')
    return config

def valid_locations(payload,now):
    rows=payload.get('locations')
    if not isinstance(rows,list):raise ValueError('Invalid locations')
    valid=[]
    for row in rows:
        if not isinstance(row,dict):continue
        try:
            if any(isinstance(row.get(k),bool) for k in ('latitude','longitude','located_time')):continue
            lat,lon=float(row['latitude']),float(row['longitude']);located=int(row['located_time'])
            if not math.isfinite(lat) or not math.isfinite(lon) or not -90<=lat<=90 or not -180<=lon<=180 or not 0<located<=now+300000:continue
            item=dict(latitude=lat,longitude=lon,located_at=located)
            # Accuracy is optional and is never inferred from coordinates.
            accuracy=row.get('accuracy')
            if accuracy is not None and not isinstance(accuracy,bool):
                try:
                    accuracy=float(accuracy)
                    if math.isfinite(accuracy) and accuracy>=0:item['accuracy_m']=accuracy
                except (ValueError,TypeError,OverflowError):pass
            valid.append(item)
        except (ValueError,TypeError,KeyError,OverflowError):continue
    return valid

def latest_location(payload,now):
    points=valid_locations(payload,now)
    return max(points,key=lambda r:r['located_at']) if points else None

class MDM:
    def __init__(self,root,store=None,auth=None):
        self.auth=auth if auth is not None else dict(lock=threading.Lock(),identity=None,token=None,until=0)
        self.adapters={}
        self.store=store
        self.path=Path(root)/'mdm.json';self.lock=threading.Lock();self.cache=None;self.next_check=0;self.token=None;self.token_until=0;self.identity=None

    def read_config(self):
        return validate_config(json.loads(self.path.read_text()))

    def resolve(self,device=None):
        config=self.read_config()
        if device and device!=config['pos_device']:
            if self.store is None:raise ValueError('Equipo no vinculado')
            with self.store.connect() as db:row=db.execute('SELECT mdm_device FROM mdm_links WHERE device=?',(device,)).fetchone()
            if row is None:raise ValueError('Equipo pendiente de vincular a ManageEngine')
            config=dict(config,pos_device=device,mdm_device=row['mdm_device'])
        elif self.store is not None:
            with self.store.connect() as db:
                if db.execute("SELECT 1 FROM sqlite_master WHERE name='mdm_links'").fetchone():
                    row=db.execute('SELECT mdm_device FROM mdm_links WHERE device=?',(config['pos_device'],)).fetchone()
                    if row:config=dict(config,mdm_device=row['mdm_device'])
        return validate_config(config)

    def get_for(self,config):
        key=(config['pos_device'],config['mdm_device'])
        with self.lock:
            adapter=self.adapters.get(key)
            if adapter is None:adapter=MDM(self.path.parent,self.store,self.auth);self.adapters[key]=adapter
        return adapter.get(config)

    def snapshot(self):
        result=dict(self.cache or dict(configured=True,status='pending',location=None,checked_at=None))
        if result.get('location'):
            result['location']=dict(result['location']);result['location']['stale']=int(time.time()*1000)-result['location']['located_at']>3600000
        return result

    def get(self,config):
        identity=(config['pos_device'],config['mdm_device'],config['client_id'],config['client_secret'],config['refresh_token'])
        if not self.lock.acquire(blocking=False):
            return self.snapshot() if identity==self.identity else dict(configured=True,status="pending",location=None,checked_at=None)
        try:
            if identity!=self.identity:
                self.identity=identity;self.cache=None;self.next_check=0;self.token=None;self.token_until=0
                if self.store is not None:
                    previous=self.store.last_geo_point(config)
                    if previous:self.cache=dict(configured=True,status='pending',location=previous,checked_at=None)
            if time.monotonic()<self.next_check:return self.snapshot()
            try:
                self.refresh(config)
                self.next_check=time.monotonic()+300
            except Exception:
                # Never expose upstream payloads, token errors, URLs or credentials.
                self.cache=dict(self.cache or dict(configured=True,location=None,checked_at=None),status='unavailable',message='No se pudo consultar ManageEngine. Se conserva la última ubicación disponible.')
                self.next_check=time.monotonic()+60
            return self.snapshot()
        finally:self.lock.release()

    def refresh(self,config):
        for attempt in range(2):
            identity=(config['client_id'],config['client_secret'],config['refresh_token'])
            with self.auth['lock']:
                if self.auth['identity']!=identity or not self.auth['token'] or time.monotonic()>=self.auth['until']:
                    reply=request_json(TOKEN,dict(grant_type='refresh_token',client_id=config['client_id'],client_secret=config['client_secret'],refresh_token=config['refresh_token']))
                    token=reply.get('access_token')
                    if not isinstance(token,str) or not token or len(token)>2048 or any(ord(c)<33 or ord(c)>126 for c in token):raise ValueError('Token unavailable')
                    self.auth.update(identity=identity,token=token,until=time.monotonic()+max(1,min(3600,int(reply.get('expires_in',3600)))-60))
                self.token=self.auth['token'];self.token_until=self.auth['until']
            try:
                reply=request_json(API+'/api/v1/mdm/devices/'+config['mdm_device']+'/locations',token=self.token)
                break
            except urllib.error.HTTPError as error:
                if error.code!=401 or attempt:raise
                with self.auth['lock']:
                    if self.auth['token']==self.token:self.auth['token']=None
                self.token=None
        now=int(time.time()*1000);points=valid_locations(reply,now)
        if self.store is not None:self.store.save_geo_points(config,points,now)
        location=self.store.last_geo_point(config) if self.store is not None else (max(points,key=lambda r:r['located_at']) if points else None)
        self.cache=dict(configured=True,status='ok' if location else 'empty',location=location,checked_at=now)
        if location:
            location['map_url']='https://www.google.com/maps/search/?api=1&query='+urllib.parse.quote(str(location['latitude'])+','+str(location['longitude']))

    def collect(self,stop):
        """Run on the HP even when no browser is open; get() enforces API backoff."""
        while not stop.is_set():
            try:
                if self.path.exists() and self.store is not None:
                    config=self.resolve()
                    with self.store.connect() as db:
                        enabled=db.execute("SELECT 1 FROM devices WHERE id=? AND enabled=1",(config["pos_device"],)).fetchone()
                    if enabled:self.get_for(config)
                    with self.store.connect() as db:
                        links=db.execute("SELECT l.device FROM mdm_links l JOIN devices d ON d.id=l.device WHERE d.enabled=1 AND l.device<>?",(config['pos_device'],)).fetchall() if db.execute("SELECT 1 FROM sqlite_master WHERE name='mdm_links'").fetchone() else []
                    for link in links:
                        if stop.is_set():break
                        self.get_for(self.resolve(link['device']))
            except Exception:
                pass  # No upstream details or credentials in logs; next loop retries.
            stop.wait(30)
