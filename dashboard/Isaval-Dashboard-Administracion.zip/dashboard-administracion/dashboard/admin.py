"""Authenticated, device-scoped maintenance commands. The terminal owns its stock."""
import base64,hashlib,hmac,json,re,secrets,time,uuid
from .store import text,integer,cents

KINDS=('product','customer','user','business','stock')
CUSTOMER_FIELDS={'name':100,'phone':30,'email':120,'legal_name':160,'nit':30,'nrc':30,'address':240,'activity':160}

def init(store):
    with store.connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS admin_devices(device TEXT PRIMARY KEY,epoch INTEGER NOT NULL,seen INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS admin_entities(device TEXT NOT NULL,epoch INTEGER NOT NULL,kind TEXT NOT NULL,entity TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT,PRIMARY KEY(device,epoch,kind,entity));
        CREATE TABLE IF NOT EXISTS admin_commands(id TEXT PRIMARY KEY,device TEXT NOT NULL,epoch INTEGER NOT NULL,kind TEXT NOT NULL,entity TEXT NOT NULL,expected INTEGER NOT NULL,action TEXT NOT NULL,payload TEXT NOT NULL,actor TEXT NOT NULL,created INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',delivered INTEGER NOT NULL DEFAULT 0,result TEXT);
        CREATE INDEX IF NOT EXISTS admin_queue ON admin_commands(device,status,created);
        """)

def enabled(db,device,token=None):
    row=db.execute('SELECT * FROM devices WHERE id=?',(device,)).fetchone()
    if row is None or not row['enabled']:raise PermissionError('Equipo desactivado o no disponible')
    if token is not None and not hmac.compare_digest(row['token_hash'],hashlib.sha256(token.encode()).hexdigest()):raise PermissionError('Dispositivo no autorizado')
    return row

def safe_data(kind,data):
    if not isinstance(data,dict):raise ValueError('Ficha inválida')
    # Projection is explicitly whitelisted: no PINs, hashes, private paths or credentials.
    fields={'product':('id','business','name','ticket_name','code','category','price','cost','stock','minimum','active','last_move','has_image','preparation'),
            'customer':('id','business',*CUSTOMER_FIELDS,'active','updated'),
            'user':('id','name','role','active','businesses'),
            'business':('items',),'stock':('id','product_id','business','delta','before_stock','after_stock','reason','cashier','created')}[kind]
    value={k:data[k] for k in fields if k in data}
    if len(json.dumps(value))>10000:raise ValueError('Ficha demasiado grande')
    return value

def exchange(store,device,token,body):
    if not isinstance(body,dict) or body.get('protocol')!=1:raise ValueError('Protocolo inválido')
    epoch=integer(body.get('epoch'),1);events=body.get('events');results=body.get('results',[])
    if not isinstance(events,list) or len(events)>25 or not isinstance(results,list) or len(results)>25:raise ValueError('Lote inválido')
    prepared=[]
    for event in events:
        kind=event.get('kind');entity=str(event.get('entity',''));revision=integer(event.get('revision'),1)
        if kind not in KINDS or not re.fullmatch(r'[0-9]{1,18}|catalog',entity):raise ValueError('Referencia inválida')
        data=event.get('data');prepared.append((kind,entity,revision,None if data is None else json.dumps(safe_data(kind,data),ensure_ascii=False)))
    now=int(time.time()*1000)
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE');enabled(db,device,token)
        current=db.execute('SELECT epoch FROM admin_devices WHERE device=?',(device,)).fetchone()
        sales=db.execute('SELECT epoch FROM devices WHERE id=?',(device,)).fetchone()
        if epoch<sales['epoch'] or current and epoch<current['epoch']:raise LookupError('Generación anterior')
        if current is None or current['epoch']!=epoch:
            db.execute('DELETE FROM admin_entities WHERE device=?',(device,))
            db.execute("UPDATE admin_commands SET status='review',result=? WHERE device=? AND status='pending' AND epoch<>?",(json.dumps({'message':'El equipo fue restaurado o vinculado nuevamente. Revisa antes de repetir.'}),device,epoch))
        db.execute('INSERT OR REPLACE INTO admin_devices VALUES(?,?,?)',(device,epoch,now))
        for kind,entity,revision,payload in prepared:
            db.execute('INSERT INTO admin_entities VALUES(?,?,?,?,?,?) ON CONFLICT(device,epoch,kind,entity) DO UPDATE SET revision=excluded.revision,payload=excluded.payload WHERE excluded.revision>admin_entities.revision',(device,epoch,kind,entity,revision,payload))
        for result in results:
            if not isinstance(result,dict) or result.get('status') not in ('applied','review'):raise ValueError('Confirmación inválida')
            message=text(result.get('message',''),300);entity=text(str(result.get('entity','')),100)
            db.execute("UPDATE admin_commands SET status=?,result=? WHERE id=? AND device=? AND epoch=? AND status='pending' AND delivered=1",(result['status'],json.dumps(dict(message=message,entity=entity)),str(result.get('id','')),device,epoch))
        db.execute("UPDATE admin_commands SET status='review',result=? WHERE device=? AND status='pending' AND delivered=0 AND created<?",(json.dumps({'message':'Cambio sin entregar durante siete días; revisa antes de repetir.'}),device,now-7*86400000))
        command=db.execute("SELECT id,epoch,kind,entity,expected,action,payload,actor FROM admin_commands WHERE device=? AND epoch=? AND status='pending' ORDER BY created,id LIMIT 1",(device,epoch)).fetchone()
        commands=[]
        if command:
            db.execute('UPDATE admin_commands SET delivered=1 WHERE id=?',(command['id'],))
            c=dict(command);c['payload']=json.loads(c['payload']);commands.append(c)
        return dict(protocol=1,device=device,epoch=epoch,accepted=[dict(kind=k,entity=e,revision=r) for k,e,r,p in prepared],received=[str(r.get('id','')) for r in results],commands=commands)

def state(store,device,kind='product',page=0,q='',business=''):
    if kind not in KINDS or not 0<=page<=2000:raise ValueError('Consulta inválida')
    with store.connect() as db:
        enabled(db,device);generation=db.execute('SELECT * FROM admin_devices WHERE device=?',(device,)).fetchone()
        if generation is None:return dict(ready=False,rows=[],total=0,epoch=0,seen=0)
        # SQL LIKE search is escaped; only one bounded page is loaded into Python.
        needle='%'+q[:100].replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%'
        args=[device,generation['epoch'],kind,needle]
        where="device=? AND epoch=? AND kind=? AND payload IS NOT NULL AND payload LIKE ? ESCAPE '\\'"
        if business:where+=" AND json_extract(payload,'$.business')=?";args.append(business)
        total=db.execute('SELECT count(*) FROM admin_entities WHERE '+where,args).fetchone()[0]
        rows=db.execute('SELECT entity,revision,payload FROM admin_entities WHERE '+where+' ORDER BY CAST(entity AS INTEGER),entity LIMIT 100 OFFSET ?',(*args,page*100)).fetchall()
        output=[]
        for row in rows:
            data=json.loads(row['payload'])
            if kind=='stock':
                product=db.execute("SELECT payload FROM admin_entities WHERE device=? AND epoch=? AND kind='product' AND entity=?",(device,generation['epoch'],str(data.get('product_id','')))).fetchone()
                data['product_name']=json.loads(product['payload']).get('name','') if product and product['payload'] else 'Producto #'+str(data.get('product_id',''))
            output.append(dict(entity=row['entity'],revision=row['revision'],data=data))
        return dict(ready=True,epoch=generation['epoch'],seen=generation['seen'],total=total,page=page,has_more=(page+1)*100<total,rows=output)

def clean_command(kind,action,payload,new):
    if kind not in ('product','customer','user','business') or not isinstance(payload,dict):raise ValueError('Cambio inválido')
    value={}
    if action in ('stock_delta','stock_count'):
        if kind!='product' or new:raise ValueError('Selecciona un producto existente')
        value['quantity']=integer(payload.get('quantity'),-1000000 if action=='stock_delta' else 0,1000000)
        if action=='stock_delta' and not value['quantity']:raise ValueError('La cantidad debe ser distinta de cero')
        value['reason']=text(payload.get('reason',''),200)
        if not value['reason'].strip():raise ValueError('Ingresa el motivo')
    elif action=='save':
        value['name']=text(payload.get('name',''),100).strip()
        if not value['name']:raise ValueError('Ingresa el nombre')
        active=payload.get('active',1)
        if type(active) is not int or active not in (0,1):raise ValueError('Estado inválido')
        value['active']=active
        if kind=='product':
            for key,limit in [('ticket_name',28),('code',100),('category',100)]:value[key]=text(payload.get(key,''),limit).strip()
            if not value['category']:raise ValueError('Ingresa la categoría')
            for key in ('price','cost'):
                amount=cents(payload.get(key,''));value[key]=f'{amount//100}.{amount%100:02}'
            value['minimum']=integer(payload.get('minimum',0),0,1000000)
            value['preparation']=integer(payload.get('preparation',1),0,1)
            if new:value['stock']=integer(payload.get('stock',0),0,1000000)
            image=payload.get('image_data','')
            if image:
                if not isinstance(image,str) or len(image)>110000:raise ValueError('Imagen demasiado grande')
                raw=base64.b64decode(image,validate=True)
                if len(raw)>80000 or not raw.startswith(b'\xff\xd8\xff'):raise ValueError('Usa una imagen JPEG de hasta 80 KB')
                value['image_data']=image
        elif kind=='customer':
            for key,limit in CUSTOMER_FIELDS.items():value[key]=text(payload.get(key,''),limit).strip()
        elif kind=='user':
            value['role']=text(payload.get('role',''),30)
            if value['role'] not in ('Administrador','Supervisor','Cajero'):raise ValueError('Rol inválido')
            businesses=payload.get('businesses',[])
            if not isinstance(businesses,list) or len(businesses)>100:raise ValueError('Negocios inválidos')
            value['businesses']=[text(v,100) for v in businesses]
            pin=payload.get('pin','')
            if pin:
                if not isinstance(pin,str) or not re.fullmatch(r'[0-9]{4}',pin):raise ValueError('El PIN debe tener 4 dígitos')
                salt=secrets.token_bytes(16);value['salt']=base64.b64encode(salt).decode();value['pin_hash']=base64.b64encode(hashlib.pbkdf2_hmac('sha1',pin.encode(),salt,100000,32)).decode()
            elif new:raise ValueError('Crea un PIN de 4 dígitos')
        else:value['description']=text(payload.get('description',''),200)
    else:raise ValueError('Acción inválida')
    if kind!='user':
        value['business']=text(payload.get('business',''),100)
        if not value['business'] and kind!='business':raise ValueError('Selecciona un negocio')
    return value

def queue(store,body,actor):
    device=text(body.get('device',''),32);kind=body.get('kind');entity=str(body.get('entity','0'));action=body.get('action');request_id=str(body.get('request_id',''))
    try:uuid.UUID(request_id)
    except (ValueError,AttributeError):raise ValueError('Identificador de solicitud inválido')
    if not re.fullmatch('[0-9]{1,18}|catalog',entity):raise ValueError('Referencia inválida')
    epoch=integer(body.get('epoch'),1);expected=integer(body.get('expected',0),0)
    payload=clean_command(kind,action,body.get('payload'),entity=='0')
    now=int(time.time()*1000)
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE');enabled(db,device)
        old=db.execute('SELECT device,kind,entity,action FROM admin_commands WHERE id=?',(request_id,)).fetchone()
        if old:
            if tuple(old)!=(device,kind,entity,action):raise ValueError('Solicitud reutilizada para otra acción')
            return dict(id=request_id,duplicate=True)
        generation=db.execute('SELECT epoch FROM admin_devices WHERE device=?',(device,)).fetchone()
        if not generation or generation['epoch']!=epoch:raise LookupError('El equipo cambió o aún no envía su catálogo. Actualiza la página.')
        revision_entity='catalog' if kind=='business' else entity
        if entity!='0' or kind=='business':
            row=db.execute('SELECT revision,payload FROM admin_entities WHERE device=? AND epoch=? AND kind=? AND entity=?',(device,epoch,kind,revision_entity)).fetchone()
            if not row or row['payload'] is None or (action!='stock_delta' and row['revision']!=expected):raise LookupError('La ficha cambió. Actualiza y vuelve a revisar.')
        if entity!='0' and db.execute("SELECT 1 FROM admin_commands WHERE device=? AND epoch=? AND kind=? AND entity=? AND status='pending'",(device,epoch,kind,entity)).fetchone():raise LookupError('Ya hay un cambio pendiente para esta ficha.')
        db.execute('INSERT INTO admin_commands(id,device,epoch,kind,entity,expected,action,payload,actor,created) VALUES(?,?,?,?,?,?,?,?,?,?)',(request_id,device,epoch,kind,entity,expected,action,json.dumps(payload,ensure_ascii=False),actor,now))
    return dict(id=request_id,duplicate=False)

def commands(store,device,page=0):
    if not 0<=page<=2000:raise ValueError('Página inválida')
    with store.connect() as db:
        rows=db.execute('SELECT * FROM admin_commands WHERE device=? ORDER BY created DESC,id DESC LIMIT 101 OFFSET ?',(device,page*100)).fetchall()
        output=[]
        for row in rows[:100]:
            item={key:row[key] for key in ('id','device','kind','entity','action','actor','created','status','delivered')}
            item['result']=json.loads(row['result']) if row['result'] else None
            payload=json.loads(row['payload']);title=payload.get('name','')
            if not title:
                source=db.execute('SELECT payload FROM admin_entities WHERE device=? AND epoch=? AND kind=? AND entity=?',(device,row['epoch'],row['kind'],row['entity'])).fetchone()
                title=json.loads(source['payload']).get('name','') if source and source['payload'] else ''
            item['title']=title or 'Ficha #'+row['entity']
            item['detail']=('Conteo físico: ' if row['action']=='stock_count' else 'Entrada/salida: ')+str(payload['quantity'])+' unidades · '+payload['reason'] if row['action'].startswith('stock_') else 'Actualización de ficha'
            output.append(item)
        return dict(rows=output,has_more=len(rows)>100,page=page)


def cancel(store,identifier):
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute("UPDATE admin_commands SET status='cancelled' WHERE id=? AND status='pending' AND delivered=0",(identifier,)).rowcount!=1:raise LookupError('El cambio ya fue entregado o terminó; no se puede cancelar.')
    return dict(ok=True)
