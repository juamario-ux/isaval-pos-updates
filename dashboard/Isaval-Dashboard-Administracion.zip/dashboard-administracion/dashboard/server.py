"""Run behind the existing HTTPS tunnel; host port binds to loopback only."""
import asyncio
import threading
from contextlib import asynccontextmanager
import hashlib
import hmac
import json
import os
import secrets
import time
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from .store import Store, text
from .mdm import MDM

STATIC=Path(__file__).with_name("static")
MAX_BODY=192*1024


def password_hash(password, salt):
    return hashlib.pbkdf2_hmac("sha256",password.encode(),bytes.fromhex(salt),310000).hex()


def create_app(data_path=None, config=None):
    data_path=Path(data_path or os.environ.get("DASHBOARD_DATA","/data"))
    if config is None:
        config_path=data_path/"config.json"
        config=json.loads(config_path.read_text()) if config_path.exists() else {}
    store=Store(data_path/"dashboard.sqlite3")
    mdm=MDM(data_path,store)
    @asynccontextmanager
    async def lifespan(app):
        stop=threading.Event()
        worker=threading.Thread(target=mdm.collect,args=(stop,),name="isaval-mdm-history",daemon=True)
        worker.start()
        try:yield
        finally:
            stop.set()
            await run_in_threadpool(worker.join,15)
    app=FastAPI(title="Isaval Pos Dashboard",docs_url=None,redoc_url=None,openapi_url=None,lifespan=lifespan)
    app.state.store=store
    app.state.mdm=mdm
    cookie_secure=config.get("secure_cookie",True)

    @app.middleware("http")
    async def headers(request,call_next):
        response=await call_next(request)
        response.headers.update({"Cache-Control":"no-store","X-Content-Type-Options":"nosniff","Referrer-Policy":"strict-origin-when-cross-origin","Content-Security-Policy":"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://tile.openstreetmap.org; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'","Permissions-Policy":"camera=(), microphone=(), geolocation=()"})
        return response

    async def body(request,limit=MAX_BODY):
        if request.headers.get("content-type","").split(";")[0]!="application/json":
            raise HTTPException(415,"Usa JSON")
        if request.headers.get("content-encoding", "identity")!="identity":
            raise HTTPException(415,"Codificación no admitida")
        data=bytearray()
        async for chunk in request.stream():
            data.extend(chunk)
            if len(data)>limit:
                raise HTTPException(413,"Lote demasiado grande")
        try:
            return json.loads(data)
        except (ValueError,UnicodeError):
            raise HTTPException(400,"JSON inválido")

    def session(request):
        token=request.cookies.get("isaval_session","")
        if len(token)>100:
            raise HTTPException(401,"Inicia sesión")
        with store.connect() as db:
            row=db.execute("SELECT * FROM sessions WHERE hash=? AND expires>?",(hashlib.sha256(token.encode()).hexdigest(),int(time.time()))).fetchone()
        if row is None:
            raise HTTPException(401,"Inicia sesión")
        return row

    def same_origin(request):
        origin=request.headers.get("origin")
        expected=config.get("origin","")
        if origin and origin!=expected:
            raise HTTPException(403,"Origen no autorizado")

    @app.get("/healthz")
    def health():
        return {"status":"ok","service":"Isaval Pos Dashboard","protocol":1}

    @app.post("/api/login")
    async def login(request:Request):
        same_origin(request)
        if not config.get("password_hash"):
            raise HTTPException(503,"Servidor pendiente de configuración")
        values=await body(request,2048)
        if not isinstance(values,dict):
            raise HTTPException(400,"Datos inválidos")
        username,password=values.get("username",""),values.get("password","")
        if not isinstance(username,str) or not isinstance(password,str) or len(username)>100 or len(password)>256:
            raise HTTPException(400,"Datos inválidos")
        key=request.client.host if request.client else "local"
        def authenticate():
            now=int(time.time())
            with store.connect() as db:
                db.execute("BEGIN IMMEDIATE")
                row=db.execute("SELECT * FROM login_limits WHERE key=?",(key,)).fetchone()
                if row and row["expires"]>now and row["attempts"]>=5:
                    raise HTTPException(429,"Espera cinco minutos antes de volver a intentar")
                attempts=1 if not row or row["expires"]<=now else row["attempts"]+1
                db.execute("INSERT OR REPLACE INTO login_limits VALUES(?,?,?)",(key,attempts,now+300 if not row or row["expires"]<=now else row["expires"]))
            valid=hmac.compare_digest(password_hash(password,config["salt"]),config["password_hash"]) & hmac.compare_digest(username.encode(),config["username"].encode())
            if not valid:
                raise HTTPException(401,"Usuario o contraseña incorrectos")
            token,csrf=secrets.token_urlsafe(32),secrets.token_urlsafe(24)
            with store.connect() as db:
                db.execute("DELETE FROM login_limits WHERE key=?",(key,))
                db.execute("DELETE FROM sessions WHERE expires<=?",(now,))
                db.execute("INSERT INTO sessions VALUES(?,?,?)",(hashlib.sha256(token.encode()).hexdigest(),csrf,now+8*3600))
            return token,csrf
        token,csrf=await run_in_threadpool(authenticate)
        response=JSONResponse({"username":config["username"],"csrf":csrf})
        response.set_cookie("isaval_session",token,httponly=True,secure=cookie_secure,samesite="strict",max_age=8*3600,path="/")
        return response

    @app.get("/api/me")
    def me(request:Request):
        row=session(request)
        return {"username":config["username"],"csrf":row["csrf"]}

    @app.post("/api/logout")
    def logout(request:Request):
        same_origin(request)
        row=session(request)
        if not hmac.compare_digest(request.headers.get("x-csrf-token",""),row["csrf"]):
            raise HTTPException(403,"Solicitud no autorizada")
        with store.connect() as db:
            db.execute("DELETE FROM sessions WHERE hash=?",(row["hash"],))
        response=JSONResponse({"ok":True})
        response.delete_cookie("isaval_session",path="/")
        return response

    def device_auth(request):
        authorization=request.headers.get("authorization","")
        device=request.headers.get("x-isaval-device","")
        if not authorization.startswith("Bearer ") or len(authorization)>150 or len(device)!=32:
            raise HTTPException(401,"Dispositivo no autorizado")
        # Authenticate before parsing an untrusted batch.
        with store.connect() as db:
            row=db.execute("SELECT token_hash,enabled FROM devices WHERE id=?",(device,)).fetchone()
        token=authorization[7:]
        if not row or not row["enabled"] or not hmac.compare_digest(row["token_hash"],hashlib.sha256(token.encode()).hexdigest()):
            raise HTTPException(401,"Dispositivo no autorizado")
        return device,token

    @app.post("/api/v1/businesses")
    async def business_names(request:Request):
        device,token=device_auth(request)
        values=await body(request)
        try:
            return await run_in_threadpool(store.put_business_names,device,token,values)
        except PermissionError:
            raise HTTPException(401,"Dispositivo no autorizado")
        except LookupError:
            raise HTTPException(409,"Generación anterior")
        except (ValueError,TypeError,KeyError,AttributeError):
            raise HTTPException(400,"Catálogo de negocios inválido")

    @app.post("/api/v1/sync")
    async def sync(request:Request):
        device,token=device_auth(request)
        values=await body(request)
        try:
            return await run_in_threadpool(store.ingest,device,token,values)
        except PermissionError:
            raise HTTPException(401,"Dispositivo no autorizado")
        except LookupError:
            raise HTTPException(409,"Generación anterior; vuelve a vincular este dispositivo")
        except (ValueError,TypeError,KeyError,AttributeError):
            raise HTTPException(400,"Lote inválido; revisa la versión de IsaVal POS")

    def filters(request):
        from datetime import datetime
        from .store import ZONE
        today=datetime.now(ZONE).date().isoformat()
        return request.query_params.get("from",today),request.query_params.get("to",today),text(request.query_params.get("business",""),100)

    @app.get("/api/location")
    def location(request:Request):
        session(request)
        if not mdm.path.exists():return dict(configured=False,status="disabled",location=None)
        try:config=mdm.resolve(request.query_params.get("device"))
        except Exception:return dict(configured=True,status="configuration_error",location=None,message="Revisa la vinculación de ManageEngine en la HP.")
        with store.connect() as db:
            device=db.execute("SELECT label FROM devices WHERE id=? AND enabled=1",(config["pos_device"],)).fetchone()
        if device is None:return dict(configured=True,status="disabled",location=None,message="El dispositivo vinculado está desactivado.")
        result=mdm.get_for(config);result["device_label"]=device["label"]
        return result

    @app.get("/api/geolocation")
    def geolocation(request:Request):
        session(request)
        if not mdm.path.exists():return dict(configured=False,status="disabled",rows=[],total=0,has_more=False)
        try:config=mdm.resolve(request.query_params.get("device"))
        except Exception:return dict(configured=True,status="configuration_error",rows=[],total=0,has_more=False)
        try:
            from datetime import datetime
            from .store import ZONE
            day=request.query_params.get("day",datetime.now(ZONE).date().isoformat())
            result=store.geo_history(config,day,int(request.query_params.get("page","0")),for_map=request.query_params.get("view")=="map")
            result["recording_interval_minutes"]=5
            return result
        except PermissionError:raise HTTPException(403,"Dispositivo desactivado")
        except (ValueError,TypeError,OverflowError):raise HTTPException(400,"Revisa el día y la página")

    @app.get("/api/summary")
    def summary(request:Request):
        session(request)
        try:
            return store.summary(*filters(request))
        except TimeoutError as error:
            raise HTTPException(503,str(error))
        except LookupError as error:
            raise HTTPException(409,str(error))
        except (ValueError,TypeError):
            raise HTTPException(400,"Intervalo no válido o demasiado amplio")

    @app.get("/api/transactions")
    def transactions(request:Request):
        session(request)
        try:
            page=int(request.query_params.get("page","0"))
            if not 0<=page<=2000:
                raise ValueError()
            return store.transactions(*filters(request),page,request.query_params.get("q",""))
        except TimeoutError as error:
            raise HTTPException(503,str(error))
        except (ValueError,TypeError):
            raise HTTPException(400,"Consulta no válida")

    @app.get("/")
    def index():
        return FileResponse(STATIC/"index.html")

    @app.get("/app.js")
    def javascript():
        return FileResponse(STATIC/"app.js",media_type="text/javascript")

    @app.get("/style.css")
    def stylesheet():
        return FileResponse(STATIC/"style.css",media_type="text/css")

    @app.get("/geo-map.js")
    def geo_map_script():
        return FileResponse(STATIC/"geo-map.js",media_type="text/javascript")

    @app.get("/vendor/{name}")
    def map_vendor(name:str):
        if name not in ("leaflet.js","leaflet.css","LEAFLET-LICENSE.txt"):raise HTTPException(404)
        return FileResponse(STATIC/"vendor"/name,media_type="text/javascript" if name.endswith(".js") else "text/css" if name.endswith(".css") else "text/plain")

    from .admin_routes import install
    install(app,store,config,session,same_origin,body,device_auth,STATIC)
    return app
