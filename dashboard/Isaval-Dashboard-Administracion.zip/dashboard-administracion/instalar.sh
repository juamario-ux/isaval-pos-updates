#!/usr/bin/env bash
set -euo pipefail
umask 077
package_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
service_dir="$HOME/isaval-pos-dashboard"
backup_stamp="$(date +%Y%m%d-%H%M%S)"
backup_dir="$HOME/isaval-pos-dashboard-backups/$backup_stamp"
cd "$service_dir"
test -f compose.yaml
test -f dashboard/store.py
mkdir -p "$backup_dir"
cp -R dashboard "$backup_dir/dashboard"
cp Dockerfile requirements.txt compose.yaml "$backup_dir/"
docker compose exec -T pos-dashboard python - "$backup_stamp" <<'BACKUP'
import sqlite3,sys
source=sqlite3.connect('/data/dashboard.sqlite3',timeout=30)
target=sqlite3.connect('/data/antes-administracion-'+sys.argv[1]+'.sqlite3')
try:
    source.backup(target)
    assert target.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
finally:
    target.close();source.close()
BACKUP
docker compose cp "pos-dashboard:/data/antes-administracion-$backup_stamp.sqlite3" "$backup_dir/dashboard.sqlite3"
docker compose cp pos-dashboard:/data/config.json "$backup_dir/config.json"
if docker compose exec -T pos-dashboard test -f /data/mdm.json; then docker compose cp pos-dashboard:/data/mdm.json "$backup_dir/mdm.json"; fi
cp "$package_dir/Dockerfile" "$package_dir/requirements.txt" .
cp -R "$package_dir/dashboard/." dashboard/
chmod -R a+rX dashboard
chmod 644 Dockerfile requirements.txt
docker compose build pos-dashboard
docker compose run --rm --no-deps pos-dashboard python -c "from dashboard.server import create_app; app=create_app(); assert app.state.store.path.exists(); print('Administración y base verificadas')"
docker compose up -d pos-dashboard
curl --fail --show-error --retry 15 --retry-all-errors --retry-delay 2 http://127.0.0.1:8095/healthz
echo
echo "Servicio actualizado. Respaldo privado: $backup_dir"
echo "Actualiza IsaVal POS desde la SUNMI, conserva su vinculación y sincroniza. Abre Administración en el Dashboard."
