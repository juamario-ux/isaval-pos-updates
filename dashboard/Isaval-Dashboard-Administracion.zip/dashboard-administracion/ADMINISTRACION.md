# Administración integral de IsaVal POS

Cada dispositivo conserva su base local y sus existencias. El Dashboard recibe una proyección incremental de productos, clientes, usuarios, negocios y movimientos de inventario; no reemplaza inventario con una copia global. Se mantiene el historial comercial existente.

## Operación

1. Actualiza el servidor HP con respaldo previo y después instala IsaVal POS 0.12.0 (54) o posterior desde Actualizaciones. No vuelvas a vincular la SUNMI existente: conserva su configuración.
2. Abre Administración y selecciona el dispositivo. Espera su primer catálogo confirmado. Productos/clientes/usuarios/negocios se consultan por páginas y con filtro de negocio/búsqueda.
3. Crea o edita fichas. El precio/costo se valida como decimal exacto, el nombre corto de ticket admite 28 caracteres y el código vacío se asigna en el equipo. Puedes enviar una fotografía JPEG reducida desde el navegador. Las fotografías locales existentes se conservan si no eliges otra; no se sube toda la galería al servidor.
4. En Inventario registra entrada/salida con cantidad firmada y motivo, o conteo físico con valor final. Una entrada/salida opera sobre las existencias disponibles al aplicarse. Un conteo físico comprueba la revisión de la ficha y requiere revisión si hubo cambios posteriores. No hay transferencias automáticas ni stock compartido entre equipos.
5. Consulta el estado del cambio: pendiente, aplicado, requiere revisión o cancelado. Una entrega sin confirmación permanece pendiente y se reintenta con el mismo identificador. No repitas movimientos pendientes. Solo puedes cancelar los que aún no fueron entregados.
6. Copiar producto crea una ficha independiente en otro equipo con stock inicial cero. Selecciona su negocio destino. La imagen de origen no se copia automáticamente; puedes asignarla al editar el nuevo producto.
7. Los usuarios administrados son cuentas/PIN de la SUNMI, con rol y negocios permitidos por equipo. No son nuevas cuentas del Dashboard. Sin negocios seleccionados tienen acceso a todos; un administrador conserva acceso completo. El último administrador activo no se puede desactivar ni degradar. Los PIN se derivan en la HP; la cola y los catálogos no guardan PIN en claro.

## Nuevos equipos y geolocalización

Agregar equipo descarga un archivo privado de vinculación. Instala y prueba la APK en el dispositivo, importa su propio archivo y sincroniza; retira el archivo de Descargas después. Un respaldo de catálogo no debe usarse para copiar la vinculación de otro equipo. Las preferencias de vinculación cifradas no están incluidas en el respaldo .ivbackup. El servidor distingue dispositivo y generación al identificar registros.

Puedes nombrar/desactivar equipos o generar una nueva vinculación que invalida la anterior. Desactivar solo bloquea comunicación con el servidor; no apaga el equipo ni sustituye el bloqueo de ManageEngine.

Registra el ID ManageEngine de cada terminal para reutilizar la autorización privada existente de solo lectura. Geolocalización permite seleccionar equipo, día y mapa. La HP recopila puntos sin navegador abierto con caché por dispositivo. Cada equipo debe estar inscrito y autorizado en la misma cuenta MDM; no se solicita GPS adicional desde IsaVal POS.

## Sincronización y recuperación

Las operaciones locales capturan cambios con disparadores SQLite. Lotes pequeños y una sola orden por respuesta limitan trabajo y memoria de la V2 Pro. No hay socket permanente ni bloqueo de la venta esperando internet. La aplicación abierta consulta con su ciclo de sincronización; en reposo Android puede diferir los trabajos. El panel muestra el último catálogo confirmado, no inventa stock en tiempo real.

El cambio y su comprobante de aplicación se guardan en una transacción local. Si se pierde una confirmación, el equipo devuelve el mismo resultado sin repetir el movimiento. Una restauración/vinculación crea una generación nueva y la HP pasa las órdenes antiguas pendientes a revisión. Los comprobantes locales de aplicación y permisos se conservan en settings, incluido en los respaldos cifrados; los índices de exportación se reconstruyen.

Productos/clientes/usuarios se inactivan en la web para conservar sus referencias. Cambiar nombre/precio/costo no altera ventas ya registradas. La administración web usa la sesión privada de administrador, origen validado y CSRF; las APIs de terminal usan su credencial exclusiva, nunca una cuenta web del empleado.

El ERP permanece independiente: no se modifica su base ni sus servicios. Antes de usar un modelo nuevo (D3 Mini, P3H u otro) prueba su impresión, pantalla, escáner, Bluetooth y venta sin internet en el hardware real.

## Catálogo y ventas abiertas

Los cambios confirmados quedan en la base local. Las ventas/carritos que ya estaban abiertos conservan los datos que el cajero tenía al prepararlos; no se les sustituye el precio durante el cobro. Para cargar el catálogo y las existencias visuales actualizados, vuelve al inicio y abre una nueva venta después de sincronizar. La validación final siempre comprueba las existencias reales en la base, aunque una pantalla anterior aún muestre otra cantidad.
